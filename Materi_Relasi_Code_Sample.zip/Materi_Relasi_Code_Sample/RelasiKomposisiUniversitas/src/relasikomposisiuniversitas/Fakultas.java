package relasikomposisiuniversitas;
public class Fakultas {
    private String namaFakultas;
    public Fakultas(String namaFakultas){
        this.namaFakultas=namaFakultas;
    }
    public String getNamaFakultas(){
        return this.namaFakultas;
    }
    public void setNamaFakultas(String namaFakultas){
        this.namaFakultas=namaFakultas;
    }
}
