package relasikomposisiuniversitas;
import java.util.LinkedList;
public class Universitas {
    private String namaUniversitas;
    private LinkedList<Fakultas> fakultas;//objek collection fakultas sebagai objek tamu
    
    public Universitas (String namaUniversitas){
        this.namaUniversitas = namaUniversitas;
        this.fakultas = new LinkedList<>();//objek tamu diinstansiasi di dalam kelas Universitas
    }
    public String getNamaUniversitas(){
        return this.namaUniversitas;
    }
    public void setNamaUniversitas(String namaUniversitas){
        this.namaUniversitas=namaUniversitas;
    }
    public LinkedList<Fakultas> getFakultas(){
        return this.fakultas;
    }
    public void setFakultas(LinkedList fakultas){
        this.fakultas=fakultas;
    }
    public void addFakultas(String namaFakultas){
        this.fakultas.add(new Fakultas (namaFakultas));
    }
}
