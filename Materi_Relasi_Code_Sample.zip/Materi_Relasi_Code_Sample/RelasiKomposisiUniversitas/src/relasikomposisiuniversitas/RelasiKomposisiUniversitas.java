package relasikomposisiuniversitas;
public class RelasiKomposisiUniversitas {
    public static void main(String[] args) {
        //instansiasi objek universitas
        //tidak ada instansiasi objek collection fakultas
        Universitas universitas = new Universitas ("Universitas Jambi"); 
         //menambahkan member pada collection fakultas
        universitas.addFakultas("Fakultas Sains dan teknologi");
        universitas.addFakultas("Fakultas Ekonomi dan Bisnis");
        universitas.addFakultas("Fakultas Hukum");
        
        System.out.println(universitas.getNamaUniversitas() + " Memiliki Fakultas sebagai berikut: ");
        for (Fakultas listFakultas: universitas.getFakultas()){
            System.out.println(listFakultas.getNamaFakultas());
        }
    }   
}
