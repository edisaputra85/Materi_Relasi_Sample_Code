/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asosiasiorangalamat;

/**
 *
 * @author admin
 */
public class AsosiasiOrangAlamat {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Orang orang = new Orang("Budi");
        Alamat alamat = new Alamat("Telanaipura");
        orang.setAlamat(alamat);
        
        System.out.println(orang.getNama() +" tinggal di " + orang.getAlamat().getAlamatRumah());
    }
    
}
