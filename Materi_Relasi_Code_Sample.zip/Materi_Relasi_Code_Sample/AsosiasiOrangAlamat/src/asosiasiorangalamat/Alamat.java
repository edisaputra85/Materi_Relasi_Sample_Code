package asosiasiorangalamat;
public class Alamat {
    private String alamatRumah;
    private Orang orang;
    
    public Alamat(String alamatRumah){
        this.alamatRumah=alamatRumah;
    }
    public String getAlamatRumah(){
        return this.alamatRumah;
    }
    public void setAlamatRumah(String alamatRumah){
        this.alamatRumah=alamatRumah;
    }
    public Orang getOrang(){
        return this.orang;
    }
    public void setOrang(Orang orang){
        this.orang=orang;
    }
}
