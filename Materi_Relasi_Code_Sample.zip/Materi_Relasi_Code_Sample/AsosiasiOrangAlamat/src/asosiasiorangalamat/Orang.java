package asosiasiorangalamat;
public class Orang {
    private String nama;
    private Alamat alamat;
    
    public Orang(String nama){
        this.nama=nama;
    }
    public String getNama(){
        return this.nama;
    }
    public void seNama(String nama){
        this.nama=nama;
    }
    public Alamat getAlamat(){
        return alamat;
    }
    public void setAlamat(Alamat alamat){
        this.alamat=alamat;
    }
}
