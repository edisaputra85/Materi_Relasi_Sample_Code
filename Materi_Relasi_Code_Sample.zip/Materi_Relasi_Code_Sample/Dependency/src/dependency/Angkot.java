package dependency;
public class Angkot {
    private String nomorAngkot;
    public Angkot(String nomorAngkot){
        this.nomorAngkot=nomorAngkot;
    }
    public String getNomorAngkot(){
        return this.nomorAngkot;
    }
    public void setNomorAngkot(String nomorAngkot){
        this.nomorAngkot = nomorAngkot;
    }  
}
