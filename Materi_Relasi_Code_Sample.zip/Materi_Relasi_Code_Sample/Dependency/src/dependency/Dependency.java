package dependency;
public class Dependency {
    public static void main(String[] args) {
        Angkot angkot = new Angkot("P103");
        Masyarakat masyarakat = new Masyarakat("1571xxx");
        masyarakat.naikAngkot(angkot);     
    }
    
}
