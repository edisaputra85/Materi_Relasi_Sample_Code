package bidirectional1m;
public class Mahasiswa {
    private String nim;
    private Beasiswa prodi;
    
    public Mahasiswa(String nim,Beasiswa prodi){
        this.nim = nim;
        this.prodi = prodi;
    }
    
    public String getNIM(){
        return nim;
    }
    public void setNIM(String nim){
        this.nim = nim;
    }
    
    public Beasiswa getProdi(){
        return prodi;
    }
    public void setProdi(Beasiswa prodi){
        this.prodi = prodi;
    }
}
