package bidirectional1m;
import java.util.LinkedList;

public class Bidirectional1M {

    public static void main(String[] args) {
        //membuat objek mahasiswa berupa collection
        LinkedList<Mahasiswa> mhs = new LinkedList<>();
        Beasiswa beasiswa = new Beasiswa("Bidikmisi");//perintah yang menciptakan relasi
        beasiswa.setMahasiswa(mhs);
        
        //association one to many
        mhs.addFirst(new Mahasiswa("F1E119040",beasiswa));//perintah yang menciptakan relasi
        mhs.addFirst(new Mahasiswa("F1E119041",beasiswa));
        
        System.out.println("List Mahasiswa " + beasiswa.getNamaBeasiswa());
        System.out.println("====================================");
        for (Mahasiswa listMhs : beasiswa.getMahasiswa()){
            System.out.println(listMhs.getNIM());
        }
    }  
}
