package bidirectional1m;
import java.util.LinkedList;
public class Beasiswa {
    private String namaBeasiswa;
    private LinkedList<Mahasiswa> mahasiswa;
    
    public Beasiswa (String namaBeasiswa){
        this.namaBeasiswa=namaBeasiswa;
    }
    public String getNamaBeasiswa(){
        return namaBeasiswa;
    }
    public void setNamaBeasiswa(String namaBeasiswa){
        this.namaBeasiswa=namaBeasiswa;
    }
    public LinkedList<Mahasiswa> getMahasiswa(){
        return mahasiswa;
    }
    public void setMahasiswa(LinkedList<Mahasiswa> mahasiswa){
        this.mahasiswa=mahasiswa;
    }   
}
