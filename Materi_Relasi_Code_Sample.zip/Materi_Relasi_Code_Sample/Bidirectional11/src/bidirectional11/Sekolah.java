package bidirectional11;
public class Sekolah {
    private String namaSekolah;//variabel instance
    private KepalaSekolah kepalaSekolah;//atribut dari kelas KepalaSekolah
    
    public Sekolah (String namaSekolah){//Konstruktor
        this.namaSekolah = namaSekolah;
    }
    public String getNamaSekolah(){
        return namaSekolah;
    }
    public void setNamaSekolah(String namaSekolah){
        this.namaSekolah = namaSekolah;
    }   
    public KepalaSekolah getKepalaSekolah(){
        return kepalaSekolah;
    }
    public void setKepalaSekolah(KepalaSekolah kepalaSekolah){
        this.kepalaSekolah = kepalaSekolah;
    }
}
