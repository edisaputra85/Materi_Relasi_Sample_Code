package bidirectional11;
public class Bidirectional11 {
    public static void main(String[] args) {
        //instansiasi objek
        Sekolah sekolah = new Sekolah ("SMAN Titian Teras");//instansiasi objek sekolah
        KepalaSekolah kepalaSekolah1 = new KepalaSekolah("Pak Teguh");//instansiasi objek kepalaSekolah1
        KepalaSekolah kepalaSekolah2 = new KepalaSekolah("Pak Pahrin");//instansiasi objek kepalaSekolah2
        
        
        //association bidirectional terjadi di sini
        sekolah.setKepalaSekolah(kepalaSekolah1);
        //memunculkan nilai dari objek sekolah
        System.out.println(sekolah.getKepalaSekolah().getNamaKepalaSekolah() 
                           + " Kepala dari " + sekolah.getNamaSekolah());
        
        //ganti objek kepala sekolah yang berelasi dengan sekolah
        sekolah.setKepalaSekolah(kepalaSekolah2);
        System.out.println("==================================");
        System.out.println(sekolah.getKepalaSekolah().getNamaKepalaSekolah() 
                           + " Kepala dari " + sekolah.getNamaSekolah());
    }   
}