package bidirectional11;
public class KepalaSekolah {
    private String namaKepalaSekolah; //variable instance
    private Sekolah sekolah;//atribut dari kelas Sekolah
    
    public KepalaSekolah(String namaKepalaSekolah){
        this.namaKepalaSekolah=namaKepalaSekolah;
    }
    public String getNamaKepalaSekolah(){
        return namaKepalaSekolah;
    }
    public void setNamaKepalaSekolah(String namaKepalaSekolah){
        this.namaKepalaSekolah=namaKepalaSekolah;
    }
    public Sekolah getSekolah(){
        return sekolah;
    }
    public void setSekolah(Sekolah sekolah){
        this.sekolah = sekolah;
    }
}
