package relasikomposisi;
import java.util.LinkedList;
public class PesertaKuliah {
    LinkedList<String> peserta = new LinkedList<>();//collection peserta kuliah diisi dengan nim, seharusnya ini bertipe Mahasiswa
    public PesertaKuliah(LinkedList<String> peserta){
        this.peserta = peserta;
    }
    public LinkedList<String> getPeserta (){
        return this.peserta;
    }
    public void setPeserta(LinkedList<String> peserta){
        this.peserta=peserta;
    }    
}
