package relasikomposisi;
public class RelasiKomposisi {
    public static void main(String[] args) {
        //Komposisi diciptakan pada saat objek kelasPerkuliahan diinstansiasi / konstruktor dipanggil
        //Saat objek kelasPerkuliahan diinstansiasi, turut diinstasiasi pula objek dari kelas PesertaKuliah dan TimPengajar.
        //objek dari kelas PesertaKuliah dan TimPengajar akan terhapus bila objek kelasPerkuliahan dihapus
        KelasPerkuliahan kelasPerkuliahan = new KelasPerkuliahan("PBO","Virtual","Senin, 11:40 - 13:20");
        
        //Menambahkan peserta kuliah
        kelasPerkuliahan.getPesertaKuliah().peserta.add("F1e119001");
        kelasPerkuliahan.getPesertaKuliah().peserta.add("F1e119002");
        kelasPerkuliahan.getPesertaKuliah().peserta.add("F1e119003");
        
        //Menambahkan tim pengajar
        kelasPerkuliahan.getTimPengajar().timPengajar.add("Edi Saputra");
        kelasPerkuliahan.getTimPengajar().timPengajar.add("Benedika Ferdian H.");
        kelasPerkuliahan.getTimPengajar().timPengajar.add("Daniel Arsa");
        
        //Menampilkan data kelas perkuliahan
        System.out.println("Nama Matakuliah : " + kelasPerkuliahan.getMatakuliah());
        System.out.println("Jadwal Kuliah   : " + kelasPerkuliahan.getRuangKuliah());
        System.out.println("Jadwal Kuliah   : " + kelasPerkuliahan.getWaktuKuliah());
        System.out.println("Tim pengajar    : ");
        for(String listPengajar: kelasPerkuliahan.getTimPengajar().timPengajar){
           System.out.println("\t\t"+listPengajar); 
        }
        System.out.println("Peserta Kuliah  : ");
        for(String listPeserta: kelasPerkuliahan.getPesertaKuliah().peserta){
           System.out.println("\t\t"+listPeserta); 
        }
    }  
}
