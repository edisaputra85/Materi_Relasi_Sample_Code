package relasikomposisi;
import java.util.LinkedList;
public class TimPengajar {
    LinkedList<String> timPengajar = new LinkedList<>();
    public TimPengajar(LinkedList<String> timPengajar){
        this.timPengajar = timPengajar;
    }
    public LinkedList<String> getTimPengajar (){
        return this.timPengajar;
    }
    public void setTimPengajar(LinkedList<String> timPengajar){
        this.timPengajar=timPengajar;
    }     
    
}
