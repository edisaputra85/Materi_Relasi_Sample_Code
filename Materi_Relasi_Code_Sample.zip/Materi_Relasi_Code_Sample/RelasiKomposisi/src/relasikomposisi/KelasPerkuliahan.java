package relasikomposisi;
import java.util.LinkedList;
public class KelasPerkuliahan {
    private String matakuliah,ruangKuliah,waktuKuliah;
    private PesertaKuliah pesertaKuliah;
    private TimPengajar timPengajar;
    private LinkedList<String> peserta = new LinkedList<>();
    private LinkedList<String> pengajar = new LinkedList<>();
    public KelasPerkuliahan(String matakuliah, String ruangKuliah, String waktuKuliah){
        this.matakuliah=matakuliah;
        this.ruangKuliah=ruangKuliah;
        this.waktuKuliah=waktuKuliah;
        pesertaKuliah= new PesertaKuliah(peserta);
        timPengajar=new TimPengajar(pengajar);
    }
    public String getMatakuliah(){
        return this.matakuliah;}    
    public void setMatakuliah(String matakuliah){
        this.matakuliah=matakuliah;}
    public String getRuangKuliah(){
        return this.ruangKuliah;
    }    
    public void setRuangKuliah(String ruangKuliah){
        this.ruangKuliah=ruangKuliah;
    }
    public String getWaktuKuliah(){
        return this.waktuKuliah;
    }    
    public void setWaktuKuliah(String waktuKuliah){
        this.waktuKuliah=waktuKuliah;
    }
    public PesertaKuliah getPesertaKuliah(){
        return this.pesertaKuliah;
    }    
    public void setPesertaKuliah(PesertaKuliah pesertaKuliah){
        this.pesertaKuliah=pesertaKuliah;
    }
    public TimPengajar getTimPengajar(){
        return this.timPengajar;
    }    
    public void setTimPengajar(TimPengajar timPengajar){
        this.timPengajar=timPengajar;
    }
}
