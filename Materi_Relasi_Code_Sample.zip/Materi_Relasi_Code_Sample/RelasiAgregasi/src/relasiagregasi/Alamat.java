package relasiagregasi;
public class Alamat {
    private String kelurahan;
    private String kecamatan;
    private String kota;
    private String propinsi;
    
    public Alamat (String kelurahan, String kecamatan, String kota, String propinsi){
        this.kelurahan=kelurahan;
        this.kecamatan=kecamatan;
        this.kota=kota;
        this.propinsi=propinsi;
    }
    public String getKelurahan(){
        return this.kelurahan;
    }
    private void setKelurahan(String kelurahan){
        this.kelurahan=kelurahan;
    }
    public String getKecamatan(){
        return this.kecamatan;
    }
    public void setKecamatan(String kecamatan){
        this.kecamatan=kecamatan;
    }
    public String getKota(){
        return this.kota;
    }
    public void setKota(String kota){
        this.kota=kota;
    }
    public String getPropinsi(){
        return this.propinsi;
    }
    public void setPropinsi(String propinsi){
        this.propinsi=propinsi;
    }
    public void tampil(){
        System.out.println("Desa/kelurahan :"+this.kelurahan);
        System.out.println("Kecamatan :"+this.kecamatan);
        System.out.println("Kabupaten/Kota :"+this.kota);
        System.out.println("Propinsi :"+this.propinsi);
    }  
}
