package relasiagregasi;
import java.util.LinkedList;
public class Prodi {
    private String namaProdi;
    private String jenjangPendidikan;
    private LinkedList<Mahasiswa> mhs;
    
    //Sewaktu konstruktor Prodi dipanggil, disertakan objek collection mhs 
    //sebagai atribut pada prodi yang sudah ada
    //Jika objek dari kelas prodi dimusnahkan, maka objek dari kelas mahasiswa akan tetap ada
    //Class Prodi sebagai parent, akan menggunakan objek dari class Mahasiswa;
    //Relasi HAS A: Prodi memiliki mahasiswa
    public Prodi(String namaProdi, String jenjangPendidikan){
        this.namaProdi = namaProdi;
        this.jenjangPendidikan=jenjangPendidikan;
    }
    public String getNamaProdi(){
        return this.namaProdi;
    }
    public void setNamaProdi(String namaProdi){
        this.namaProdi=namaProdi;
    }
    
    public String getJenjangPendidikan(){
        return this.jenjangPendidikan;
    }
    public void setJenjangPendidikan(String jenjangPendidikan){
        this.jenjangPendidikan=jenjangPendidikan;
    }
    
    public LinkedList<Mahasiswa> getMahasiswa(){
        return this.mhs;
    }
    public void setMahasiswa(LinkedList<Mahasiswa> mhs){
        this.mhs=mhs;
    }
    public void tampil(){
        System.out.println("Nama Prodi = " + this.namaProdi);
        System.out.println("Jenjang Pendidikan = " + this.jenjangPendidikan);
    }
}
