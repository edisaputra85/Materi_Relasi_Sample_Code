package relasiagregasi;
import java.util.LinkedList;
public class RelasiAgregasi {
    public static void main(String[] args) {
        // TODO code application logic here
        //pembentukan objek collection mahasiswa
        LinkedList<Mahasiswa> mahasiswa = new LinkedList<>();
        
        //relasi diciptakan di sini (pada konstruktor) 
        //atau dapat pula diciptakan dengan memanggila method prodi.setMahasiswa
        Prodi prodi = new Prodi ("Sistem Informasi","Sarjana");
        prodi.setMahasiswa(mahasiswa);//agregasi di sini
        mahasiswa.add(new Mahasiswa("",""));
        
      //tambahkan mahasiswa:
        prodi.getMahasiswa().add(new Mahasiswa("F1E119001","Andi"));
        prodi.getMahasiswa().add(new Mahasiswa("F1E119002","Budi"));
        prodi.getMahasiswa().add(new Mahasiswa("F1E119001","Doli"));
       
        System.out.println("Daftar Mahasiswa Prodi "+prodi.getNamaProdi());
        System.out.println("=============================================");
        for(Mahasiswa listMhs: prodi.getMahasiswa()){
           System.out.println(listMhs.getNim() + " " + listMhs.getNama()); 
        } 
        System.out.println("=============================================");
        for(Mahasiswa listMhs2: mahasiswa){
           System.out.println(listMhs2.getNim() + " " + listMhs2.getNama()); 
        } 
        
        mahasiswa.add(new Mahasiswa("F1E119004","Dedi"));
        System.out.println("Daftar Mahasiswa Prodi "+prodi.getNamaProdi());
        System.out.println("=============================================");
        for(Mahasiswa listMhs: prodi.getMahasiswa()){
           System.out.println(listMhs.getNim() + " " + listMhs.getNama()); 
        } 
        
        
        
        
    }  
}
