package bidirectionalmm;
public class Matakuliah {
    private String namaMatakuliah;
    private String kodeMatakuliah;
    private int sksMatakuliah;
    
    public Matakuliah(String namaMatakuliah,String kodeMatakuliah,int sksMatakuliah){
        this.namaMatakuliah=namaMatakuliah;
        this.kodeMatakuliah=kodeMatakuliah;
        this.sksMatakuliah=sksMatakuliah;
    }
    
    public String getNamaMatakuliah(){
        return namaMatakuliah;
    }
    public void setNamaMatakuliah(String namaMatakuliah){
        this.namaMatakuliah=namaMatakuliah;
    }
    
    public String getKodeMatakuliah(){
        return kodeMatakuliah;
    }
    public void setKodeMatakuliah(String kodeMatakuliah){
        this.kodeMatakuliah=kodeMatakuliah;
    }
    
    public int getSksMatakuliah(){
        return sksMatakuliah;
    }
    public void setSksMatakuliah(int sksMatakuliah){
        this.sksMatakuliah=sksMatakuliah;
    }    
}
