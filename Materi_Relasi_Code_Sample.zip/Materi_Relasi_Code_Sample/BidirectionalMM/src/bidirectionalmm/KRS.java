package bidirectionalmm;
import java.util.LinkedList;
public class KRS {
    //instansiasi objek collection kelas dan mahasiswa
    LinkedList<Matakuliah> mk = new LinkedList<>();
    LinkedList<Mahasiswa> mhs = new LinkedList<>();
    
    //fungsi menambah elemen mk
    public void addMatakuliah(String namaMatakuliah,String kodeMatakuliah,int sksMatakuliah){
        mk.addLast(new Matakuliah(namaMatakuliah,kodeMatakuliah,sksMatakuliah));
        //mk[0]=objek Matakuliah ke-0 (nama,kode,sks);
        //mk[1]=objek Matakuliah ke-1 (nama,kode,sks);    
    }
    //fungsi menambah elemen mhs  
    public void addMahasiswa(String nim){
        mhs.add(new Mahasiswa(nim));
    }
    //fungsi mapping (isi KRS)
    public void mappingKRS(Mahasiswa mahasiswa, Matakuliah matakuliah){
        System.out.println(mahasiswa.getNIM() +" mengambil matakuliah "+ matakuliah.getNamaMatakuliah());   
    }   
}
